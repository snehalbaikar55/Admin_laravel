<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Tblkeywords;

class TblkeywordsController extends Controller
{
    public function index()
    {
        $tblkeywords = Tblkeywords::all();
		return response()->json($tblkeywords);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $newtblkeywords = new Tblkeywords([
            'PropertyID' => $request->get('PropertyID'),
            'metadescription' => $request->get('metadescription'),
            'keywords' => $request->get('keywords'),
            'ListingDate' => $request->get('ListingDate'),
            'Msg' => $request->get('Msg'),
            'updatedby' => $request->get('updatedby'),
            'updationDate' => $request->get('updationDate')
		]);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $request->validate([
            'PropertyID' =>'required',
            'metadescription' => 'required',
            'keywords' =>'required',
            'ListingDate' => 'required',
            'Msg' => 'required',
            'updatedby' => 'required',
            'updationDate' => 'required'
		]);

		$newtblkeywords = new Tblkeywords([
            'PropertyID' => $request->get('PropertyID'),
            'metadescription' => $request->get('metadescription'),
            'keywords' => $request->get('keywords'),
            'ListingDate' => $request->get('ListingDate'),
            'Msg' => $request->get('Msg'),
            'updatedby' => $request->get('updatedby'),
            'updationDate' => $request->get('updationDate')
		]);

		$newtblkeywords->save();

		return response()->json($newTblkeywords);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($ID)
    {
        $tblkeywords = Tblkeywords::findOrFail($ID);
		return response()->json($tblkeywords);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($ID)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $ID)
    {
        // $Crm = Crm::findOrFail($id);

		// $request->validate([
		// 	'slug' => 'slug',
		// 	'teamname' => 'teamname'
		// ]);

		// $Crm->slug = $request->get('slug');
		// $Crm->teamname = $request->get('teamname');

		// $Crm->save();

		// return response()->json($Crm);

        $tblkeywords = Tblkeywords::findOrFail($ID);
		
		$tblkeywords = Tblkeywords::find($ID);
        $tblkeywords->update($request->all());
        return $tblkeywords;
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($ID)
    {
        $tblkeywords = Tblkeywords::findOrFail($ID);
		$tblkeywords->delete();

		return response()->json($Tblkeywords::all());
    }
}
