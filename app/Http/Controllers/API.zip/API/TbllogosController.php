<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Tbllogos;

class TbllogosController extends Controller
{
    public function index()
    {
        $tbllogos = Tbllogos::all();
		return response()->json($tbllogos);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $newtbllogos = new Tbllogos([
            'PropertyID' => $request->get('PropertyID'),
            'FeaturedImage' => $request->get('FeaturedImage'),
            'source' => $request->get('source'),
            'ListingDate' => $request->get('ListingDate'),
            'updatedby' => $request->get('updatedby'),
            'updationDate' => $request->get('updationDate')
		]);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $request->validate([
            'PropertyID' =>'required',
            'FeaturedImage' => 'required',
            'source' =>'required',
            'ListingDate' => 'required',
            'updatedby' => 'required',
            'updationDate' => 'required'
		]);

		$newtbllogos = new Tbllogos([
            'PropertyID' => $request->get('PropertyID'),
            'FeaturedImage' => $request->get('FeaturedImage'),
            'source' => $request->get('source'),
            'ListingDate' => $request->get('ListingDate'),
            'updatedby' => $request->get('updatedby'),
            'updationDate' => $request->get('updationDate')
		]);

		$newtbllogos->save();

		return response()->json($newTbllogos);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($ID)
    {
        $tbllogos = Tbllogos::findOrFail($ID);
		return response()->json($tbllogos);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($ID)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $ID)
    {
        // $Crm = Crm::findOrFail($id);

		// $request->validate([
		// 	'slug' => 'slug',
		// 	'teamname' => 'teamname'
		// ]);

		// $Crm->slug = $request->get('slug');
		// $Crm->teamname = $request->get('teamname');

		// $Crm->save();

		// return response()->json($Crm);

        $tbllogos = Tbllogos::findOrFail($ID);
		
		$tbllogos = Tbllogos::find($ID);
        $tbllogos->update($request->all());
        return $tbllogos;
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($ID)
    {
        $tbllogos = Tbllogos::findOrFail($ID);
		$tbllogos->delete();

		return response()->json($Tbllogos::all());
    }
}
