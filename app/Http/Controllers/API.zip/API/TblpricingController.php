<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\tblpricing;

class TblpricingController extends Controller
{
    public function index()
    {
        $tblpricing = tblpricing::all();
		return response()->json($tblpricing);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $newtblpricing = new tblpricing([
			//'slug' => $request->get('slug'),
			'AdminName' => $request->get('AdminName'),
            'UserName' => $request->get('UserName'),
            'MobileNumber' => $request->get('MobileNumber'),
            'Email' => $request->get('Email'),
            'Password' => $request->get('Password'),
            'AdminRegdate' => $request->get('AdminRegdate'),
            'Role' => $request->get('Role')  
		]);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $request->validate([
			//'slug' => 'required',
			'AdminName' => 'AdminName',
            'UserName'  =>  'UserName',
            'MobileNumber' => 'MobileNumber',
            'Email' => 'Email',
            'Password' => 'Password',
            'AdminRegdate' => 'AdminRegdate',
            'Role' => 'Role'
		]);

		$newtblpricing = new tblpricing([
			//'slug' => $request->get('slug'),
			'AdminName' => $request->get('AdminName'),
            'UserName' => $request->get('UserName'),
            'MobileNumber' => $request->get('MobileNumber'),
            'Email' => $request->get('Email'),
            'Password' => $request->get('Password'),
            'AdminRegdate' => $request->get('AdminRegdate'),
            'Role' => $request->get('Role')
		]);

		$newtblpricing->save();

		return response()->json($newtblpricing);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($team_id)
    {
        $tblpricing = tblpricing::findOrFail($team_id);
		return response()->json($tblpricing);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($team_id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $team_id)
    {
        // $tblpricing = tblpricing::findOrFail($id);

		// $request->validate([
		// 	'slug' => 'slug',
		// 	'teamname' => 'teamname'
		// ]);

		// $tblpricing->slug = $request->get('slug');
		// $tblpricing->teamname = $request->get('teamname');

		// $tblpricing->save();

		// return response()->json($tblpricing);

        $tblpricing = tblpricing::findOrFail($team_id);
		
		$tblpricing = tblpricing::find($team_id);
        $tblpricing->update($request->all());
        return $tblpricing;
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($team_id)
    {
        $tblpricing = tblpricing::findOrFail($team_id);
		$tblpricing->delete();

		return response()->json($tblpricing::all());
    }
}
