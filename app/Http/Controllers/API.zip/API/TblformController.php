<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use DB;
use App\Models\tblform;

class tblformController extends Controller
{
    public function index()
    {
        $tblform = tblform::all();
        return response()->json($tblform);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $newtblform = new tblform([
			'PropertyID' => $request->get('PropertyID'),
            'formname' => $request->get('formname'),
            'id1' => $request->get('id1'),
            'id2' => $request->get('id2'),
            'domain' => $request->get('domain'),
            'crmurl' => $request->get('crmurl'),
            'status' => $request->get('status'),
            'EnterDate' => $request->get('EnterDate'),
            'Msg' => $request->get('Msg')
            
		]);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $request->validate([
			'PropertyID' =>'',
            'formname' =>'required',
            'id1' => 'required',
            'id2' => 'required',
            'domain' => 'required',
            'crmurl' => '',
            'status' => '',
            'EnterDate' => '',
            'Msg' => ''
           
		]);

		$newtblform = new tblform([
			'PropertyID' => $request->get('PropertyID'),
            'formname' => $request->get('formname'),
            'id1' => $request->get('id1'),
            'id2' => $request->get('id2'),
            'domain' => $request->get('domain'),
            'crmurl' => $request->get('crmurl'),
            'status' => $request->get('status'),
            'EnterDate' => $request->get('EnterDate'),
            'Msg' => $request->get('Msg')
		]);

		$newtblform->save();

		return response()->json($newtblform);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($ID)
    {
        $tblform =  DB::table('tblform')->whereIn('PropertyID', [$ID])->get();
		return response()->json($tblform);  
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($ID)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $ID)
    {
        /* $roles = Roles::findOrFail($id);

		$request->validate([
			'slug' => 'slug',
			'name' => 'name'
		]);

		$roles->slug = $request->get('slug');
		$roles->name = $request->get('name');

		$roles->save();

		return response()->json($roles); */
		
		$tblform = Tblform::findOrFail($ID);
		
		$tblform = Tblform::find($ID);
        $tblform->update($request->all());
        return $tblform;
		
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($ID)
    {
        $tblform = Tblform::findOrFail($ID);
		$tblform->delete();

		return response()->json($tblform::all());
    }
}
