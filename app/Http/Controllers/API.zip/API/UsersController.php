<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Users;

class UsersController extends Controller
{
    public function index()
    {
        $users = users::all();
        return response()->json($users);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $newusers = new users([
			//'slug' => $request->get('slug'),
            'name'=> $request->get('name'),
            'email'=> $request->get('email'),
            'password'=> $request->get('password'),
            'password_confirmation'=> $request->get('password_confirmation'),
            'mobile_no'=> $request->get('mobile_no'),
            'role'=> $request->get('role'),
            
		]);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $request->validate([
			//'slug' => 'required',
            'name'=>'required',
            'email'=> 'required',
            'password'=> 'required',
            'password_confirmation'=> 'required',
            'mobile_no'=> 'required',
            'role'=> 'required'
		]);

		$newusers = new users([
			//'slug' => $request->get('slug'),
            'name'=> $request->get('name'),
            'email'=> $request->get('email'),
            'password'=> $request->get('password'),
            'password_confirmation'=> $request->get('password_confirmation'),
            'mobile_no'=> $request->get('mobile_no'),
            'role'=> $request->get('role'),
		]);

		$newusers->save();

		return response()->json($newusers);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($team_id)
    {
        $users = users::findOrFail($team_id);
		return response()->json($users);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($team_id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $team_id)
    {
        // $users = users::findOrFail($id);

		// $request->validate([
		// 	'slug' => 'slug',
		// 	'teamname' => 'teamname'
		// ]);

		// $users->slug = $request->get('slug');
		// $users->teamname = $request->get('teamname');

		// $users->save();

		// return response()->json($users);

        $users = users::findOrFail($team_id);
		
		$users = users::find($team_id);
        $users->update($request->all());
        return $users;
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($team_id)
    {
        $users = users::findOrFail($team_id);
		$users->delete();

		return response()->json($users::all());
    }
}
