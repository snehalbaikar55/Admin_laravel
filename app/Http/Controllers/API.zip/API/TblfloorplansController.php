<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Tblfloorplans;

class TblfloorplansController extends Controller
{
    public function index()
    {
        $tblfloorplans = Tblfloorplans::all();
		return response()->json($tblfloorplans);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $newtblfloorplans = new Tblfloorplans([
            'PropertyID' => $request->get('PropertyID'),
            'Image' => $request->get('Image'),
            'source' => $request->get('source'),
            'Title' => $request->get('Title'),
            'ListingDate' => $request->get('ListingDate'),
            'updatedby' => $request->get('updatedby'),
            'updationDate' => $request->get('updationDate')
		]);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $request->validate([
			'PropertyID' => 'required',
            'Image' => 'required',
            'source' => 'required',
            'ListingDate' => 'required',
            'updatedby' => 'required',
            'updationDate' => 'required'
		]);

		$newtblfloorplans = new Tblfloorplans([
            'PropertyID' => $request->get('PropertyID'),
            'Image' => $request->get('Image'),
            'source' => $request->get('source'),
            'Title' => $request->get('Title'),
            'ListingDate' => $request->get('ListingDate'),
            'updatedby' => $request->get('updatedby'),
            'updationDate' => $request->get('updationDate')
		]);

		$newtblfloorplans->save();

		return response()->json($newTblfloorplans);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($ID)
    {
        $tblfloorplans = Tblfloorplans::findOrFail($ID);
		return response()->json($tblfloorplans);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($ID)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $ID)
    {
        // $Crm = Crm::findOrFail($id);

		// $request->validate([
		// 	'slug' => 'slug',
		// 	'teamname' => 'teamname'
		// ]);

		// $Crm->slug = $request->get('slug');
		// $Crm->teamname = $request->get('teamname');

		// $Crm->save();

		// return response()->json($Crm);

        $tblfloorplans = Tblfloorplans::findOrFail($ID);
		
		$tblfloorplans = Tblfloorplans::find($ID);
        $tblfloorplans->update($request->all());
        return $tblfloorplans;
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($ID)
    {
        $tblfloorplans = Tblfloorplans::findOrFail($ID);
		$tblfloorplans->delete();

		return response()->json($Tblfloorplans::all());
    }
}
