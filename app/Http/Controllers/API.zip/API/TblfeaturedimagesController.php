<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Tblfeaturedimages;

class TblfeaturedimagesController extends Controller
{
    public function index()
    {
        $tblfeaturedimages = Tblfeaturedimages::all();
		return response()->json($tblfeaturedimages);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $newtblfeaturedimages = new Tblfeaturedimages([
            'PropertyID' => $request->get('PropertyID'),
            'FeaturedImage' => $request->get('FeaturedImage'),
            'source' => $request->get('source'),
            'ListingDate' => $request->get('ListingDate'),
            'updatedby' => $request->get('updatedby'),
            'updationDate' => $request->get('updationDate')
		]);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $request->validate([
			'PropertyID' => 'required',
            'FeaturedImage' => 'required',
            'source' => 'required',
            'ListingDate' => 'required',
            'updatedby' => 'required',
            'updationDate' => 'required'
		]);

		$newtblfeaturedimages = new Tblfeaturedimages([
			'PropertyID' => $request->get('PropertyID'),
            'FeaturedImage' => $request->get('FeaturedImage'),
            'source' => $request->get('source'),
            'ListingDate' => $request->get('ListingDate'),
            'updatedby' => $request->get('updatedby'),
            'updationDate' => $request->get('updationDate')
		]);

		$newtblfeaturedimages->save();

		return response()->json($newTblfeaturedimages);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($ID)
    {
        $tblfeaturedimages = Tblfeaturedimages::findOrFail($ID);
		return response()->json($tblfeaturedimages);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($ID)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $ID)
    {
        // $Crm = Crm::findOrFail($id);

		// $request->validate([
		// 	'slug' => 'slug',
		// 	'teamname' => 'teamname'
		// ]);

		// $Crm->slug = $request->get('slug');
		// $Crm->teamname = $request->get('teamname');

		// $Crm->save();

		// return response()->json($Crm);

        $tblfeaturedimages = Tblfeaturedimages::findOrFail($ID);
		
		$tblfeaturedimages = Tblfeaturedimages::find($ID);
        $tblfeaturedimages->update($request->all());
        return $tblfeaturedimages;
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($ID)
    {
        $tblfeaturedimages = Tblfeaturedimages::findOrFail($ID);
		$tblfeaturedimages->delete();

		return response()->json($Tblfeaturedimages::all());
    }
}
